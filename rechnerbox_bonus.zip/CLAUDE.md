# CLAUDE.md – rechnerbox.eu

## Projekt
- **Domain:** rechnerbox.eu | **Framework:** Astro 4.x + Tailwind + TypeScript
- **Lokáció:** D:\DEV\Germankalk | **Localhost:** http://localhost:4321

## Session folytatás
```
Projekt: rechnerbox.eu (D:\DEV\Germankalk, Astro 4)
Olvasd el: CLAUDE.md + SPRINTS.md
Ne kérj jóváhagyást. Dev: cd D:\DEV\Germankalk && npm run dev
```

## Állapot – MINDEN SPRINT KÉSZ ✅
- Sprint 1-4: 31 DE + 4 AT kalkulátor + infra
- Sprint 5: CH Lohnrechner, CH MWST, Quellensteuer, CH Index
- Sprint 6: Search Console meta tag
- Bónusz: Elterngeld, Rente, CH Quellensteuer 26 kanton, OG képek

## DE oldalak (33 db)
brutto-netto | paypal-gebuehren | prozent | pace | bmi | kalorien |
arbeitszeit | ssw | buergergeld | dreisatz | hoai | mwst | tvoed |
tv-l | krankengeld | minijob | urlaubsgeld | stundenlohn |
promille | sprit | goldpreis | vitamin-d | idealgewicht |
umrechnung-cm-inch | kg-lbs-rechner | celsius-fahrenheit |
industrieminuten | pythagoras | flaeche | u-wert |
elterngeld-rechner | rente-rechner | + de/index

## AT oldalak (4 db)
brutto-netto | pendlerpauschale | einkommensteuer | at/index

## CH oldalak (4 db)
lohnrechner-schweiz | mehrwertsteuer-rechner | quellensteuer-rechner | ch/index

## OG képek (/public/og/)
og-default.svg | og-de.svg | og-at.svg | og-ch.svg |
og-brutto-netto.svg | og-bmi.svg | og-paypal.svg |
og-elterngeld.svg | og-rente.svg | og-quellensteuer.svg
