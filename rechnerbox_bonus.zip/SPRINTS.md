# SPRINTS.md – rechnerbox.eu – ALLES FERTIG ✅

## Sprint 1 ✅ 13 DE + 2 AT + infra
## Sprint 2 ✅ TVöD/TV-L/Krankengeld/Minijob/Urlaubsgeld/AT-ESt
## Sprint 3 ✅ Promille/Stundenlohn/Sprit/Gold/VitD/Idealgewicht
## Sprint 4 ✅ cm-Inch/kg-lbs/Celsius/Industrieminuten/Pythagoras/Fläche/U-Wert
## Sprint 5 ✅ CH Lohnrechner/MWST/Index + Header/Footer/Layout
## Sprint 6 ✅ Search Console Meta Tag
## Bónusz ✅ Elterngeld + Rente + CH Quellensteuer 26 Kanton + OG képek

## Deployment lépések
1. npm run build  (D:\DEV\Germankalk)
2. dist/ mappa → Cloudflare Pages (drag & drop)
3. Domain: rechnerbox.eu → Cloudflare DNS
4. Search Console: Verify gomb

## Opcionális jövőbeli bővítések
- /de/elterngeld-plus-rechner (részletes partnerschaftsbonus)
- /ch/saule-3a-rechner (adókedvezményes megtakarítás CH)
- /de/wohngeld-rechner
- Google Analytics 4 (ga4 kód beillesztése layout-ba)
- Google AdSense (ca-pub-XXXX beillesztése layout-ba)
